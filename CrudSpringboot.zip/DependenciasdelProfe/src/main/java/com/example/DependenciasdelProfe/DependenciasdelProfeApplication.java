package com.example.DependenciasdelProfe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DependenciasdelProfeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DependenciasdelProfeApplication.class, args);
	}

}
