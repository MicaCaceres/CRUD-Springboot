package com.example.DependenciasdelProfe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DependenciasdelProfeApplicationTests {

	@Test
	void contextLoads() {
	}

}
